from django.shortcuts import render, redirect
from .models import Cliente, Producto
from .forms import AddClienteForm, EditarClienteForm, AddProductoForm
from django.contrib import messages


# Create your views here.

def ventas_view(resquest):
    num_ventas = 156
    context ={
        'num_ventas': num_ventas
    }
    return render(resquest, 'ventas.html', context)


def clientes_view(resquest):
    clientes = Cliente.objects.all()
    form_personal = AddClienteForm()
    form_editar = EditarClienteForm()
    
    context = {
        'clientes': clientes,
        'form_personal' : form_personal,
        'form_editar' : form_editar
        
    }
    return render(resquest, 'clientes.html', context)



def add_cliente_view(resquest):
    #print("Guardar clientes")
    if resquest.POST:
        form = AddClienteForm(resquest.POST, resquest.FILES)
        if form.is_valid:
            try:
                form.save()
            except:
                messages(resquest, "Error al guardar el cliente")
                return redirect('Clientes')
    return redirect('Clientes')


def edit_cliente_view(resquest):
    if resquest.POST:
        cliente = Cliente.objects.get(pR=resquest.POST.get('id_personal_eliminar'))
        form = EditarClienteForm(
            resquest.POST, resquest.FILES, instance= cliente)
        if form.is_valid:
            form.save()
    return redirect('Clientes')


def delete_cliente_view(resquest):
    if resquest.POST:
        cliente = Cliente.objects.get(pR=resquest.POST.get('id_personal_eliminar'))
        cliente.delete()
    
    return redirect('Clientes')


def productos_view(resquest):
    
    productos = Producto.objects.all()
    form_add = AddProductoForm()
    
    context = {
        'productos': productos,
        'form_add':  form_add 
    }
    return render(resquest, 'productos.html', context)


def add_producto_view(resquest):
    #print("Guardar clientes")
    if resquest.POST:
        form = AddProductoForm(resquest.POST, resquest.FILES)
        if form.is_valid:
            try:
                form.save()
            except:
                messages(resquest, "Error al guardar el producto")
                return redirect('Productos')
    return redirect('Productos')
